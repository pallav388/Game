# Snooker2D
unfinished snooker test (unity 5.x) https://unitycoder.com/blog/2020/05/19/sources-unfinished-2d-snooker-test/

### Images
![snooker2d](https://user-images.githubusercontent.com/5438317/82346528-3e59bc80-99ff-11ea-877a-76653c4a1b6e.gif)
